//我是注释
//xky
void main(){
    int a ;
    a=2*(2+3)-3;
    if (a<3){
        a=100;
    }
    return;
}