'''
@author: xky
'''
class Position:
    def __init__(self, column_number: int, line_number: int):
        self.column_number = column_number
        self.line_number = line_number
